function error_if(condition,message)
if (condition)
    error(message);
end