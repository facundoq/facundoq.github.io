clc;
clear;
